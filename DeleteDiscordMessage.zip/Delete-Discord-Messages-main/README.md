# Delete-Discord-Messages

A simple tool to delete you're messages on discord.
(it works only on Windows)
install all files or it won't work
