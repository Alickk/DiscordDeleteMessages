#ifndef Delete_h
#define Delete_h


void D_1(void);

#endif

