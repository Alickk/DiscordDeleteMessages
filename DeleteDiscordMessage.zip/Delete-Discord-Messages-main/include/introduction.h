#ifndef Introduction_H
#define Introduction_H

#include <windows.h>
#include <stdio.h>

void intro(void);
void begin(void);
#endif