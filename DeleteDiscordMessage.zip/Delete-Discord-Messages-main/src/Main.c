#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "/include/Delete.h"
#include "/include/introduction.h"
#define F8 0x77
#define F9 0x78

int main(void)
{
    int yesorno;

    intro();
    printf("Begin ?\n");
    printf("\n");
    puts("[1] Yes");
    puts("[2] No");
    printf(">: ");
    scanf("%d", &yesorno);
    if (yesorno == 1)
    {
        begin();
    }
    else if (yesorno == 2)
    {
        return EXIT_SUCCESS;
    }
    else
    {
        Sleep(300);
        system("cls");
        printf("error occurred\n");
        Sleep(500);
        return EXIT_SUCCESS;
    }

    while (1)
    {
        if (GetKeyState(F8))
        {
            D_1();
        }
    }
    if (GetKeyState(F9))
    {
        system("TASKKILL /IM DiscordTool.exe");
    }

    return EXIT_SUCCESS;
}