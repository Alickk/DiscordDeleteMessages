#include "/include/Delete.h"
#include "/include/introduction.h"
#include <windows.h>
#include <winuser.h>
#define SPACE 0x20
#define BACK 0x08
#define KEYUP 0x26
#define CTRL 0xA2
#define A 0x41
#define ENTER 0x0D

void D_1(void)
{
    keybd_event(SPACE, 0, 0, 0);
    keybd_event(SPACE, 0, 0x0002, 0);
    keybd_event(BACK, 0, 0, 0);
    keybd_event(BACK, 0, 0x0002, 0);
    keybd_event(KEYUP, 0, 0, 0);
    keybd_event(KEYUP, 0, 0x0002, 0);
    Sleep(150);
    keybd_event(CTRL, 0, 0, 0);
    keybd_event(A, 0, 0, 0);
    keybd_event(A, 0, 0x0002, 0);
    keybd_event(CTRL, 0, 0x0002, 0);
    Sleep(150);
    keybd_event(SPACE, 0, 0, 0);
    keybd_event(SPACE, 0, 0x0002, 0);
    keybd_event(ENTER, 0, 0, 0);
    keybd_event(ENTER, 0, 0x0002, 0);
    Sleep(140);
    keybd_event(ENTER, 0, 0, 0);
    keybd_event(ENTER, 0, 0x0002, 0);
    Sleep(150);
    keybd_event(BACK, 0, 0, 0);
    Sleep(400);
    keybd_event(BACK, 0, 0x0002, 0);
}
