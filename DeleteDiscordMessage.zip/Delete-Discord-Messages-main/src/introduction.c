#include "/include/Delete.h"
#include "/include/introduction.h"
#include "introduction.h"


void intro(void)
{
    system("color a");
    printf("Delete Discord Messages \n");
    printf("                           By Ace \n");
}
void begin(void)
{
        Sleep(500);
        system("cls");
        printf("to start this program you have to read the txt file \n");
        system("program.txt");
        Sleep(300);
        system("cls");
        Sleep(100);
        puts("in 15 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 14 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 13 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 12 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 11 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 10 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 9 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 8 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 7 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 6 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 5 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 4 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 3 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 2 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 1 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("in 0 seconds the program starts");
        Sleep(1000);
        system("cls");
        puts("...");
        Sleep(1000);
        FreeConsole();
}


